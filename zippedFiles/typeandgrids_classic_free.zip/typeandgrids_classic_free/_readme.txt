Type & Grids Classic v3.0.1
classic.typeandgrids.com


-----------------------------
GETTING STARTED GUIDE
-----------------------------
1) Move the unzipped folder to a location on your computer where you want to store your site.

2) Open "index.html" in your web browser.

3) Next, open "index.html" in your text editor. Locate the following lines of code near the top of the page:

<link rel="stylesheet" href="css/themes/type_04.css"> 
<link rel="stylesheet" href="css/themes/color_13.css">

4) Try changing the number "04" to "06" and the number "13" to "08". Save the page in your text editor and then refresh the page in your web browser to see the results.

5) Continue to scroll through "index.html" and edit all of the text to add your own content. Everything should be fairly intuitive and self-explanatory.


-----------------------------
ADDITIONAL HELP
-----------------------------
There are lots of helpful tips in the FAQ here:
classic.typeandgrids.com/support


-----------------------------
PRO VERSION VS FREE VERSION
-----------------------------
1) The Free version doesn’t include the custom-made, swipe-enabled image slider designed to work super-smoothly on touch devices

2) The Free version requires a “Powered by Type & Grids” link in the footer – the Pro version will look entirely like your own creation

3) The Pro version includes an additional PHP version for advanced users – it’s the same version that runs this website and is great for more complex sites with multiple pages

-----------------------------
TERMS OF USE
-----------------------------
www.typeandgrids.com/terms


Copyright 2013 Jeremiah Shoaf Design LLC. All rights reserved.